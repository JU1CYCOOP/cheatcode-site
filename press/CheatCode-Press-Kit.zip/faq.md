# CheatCode: Founder Bio and Media Q&A

## Greg Cooper, Founder
Greg Cooper is the founder of CheatCode. He built CheatCode to answer a simple question he faced every time he ate out: what can I order here that fits my calories and protein? CheatCode launched on the App Store in November 2026.


## Q&A

**What is CheatCode?**
An iPhone app that tells you what to order at more than 50 restaurant chains to fit your calorie and protein goals, with the exact words to say at the counter.

**How is it different from MyFitnessPal or other calorie trackers?**
Trackers ask you to log food after you eat it. CheatCode is not a tracker. It picks the order before you order, sizes it to your meal and writes out how to ask for it.

**What is a "cheat code"?**
A custom way of ordering a regular menu item, such as leaving off a sauce, adding free vegetables, swapping a side or picking a different size, so the meal fits your numbers. Many are based on popular orders shared on TikTok and Instagram.

**Where do the numbers come from?**
From each restaurant's own published nutrition information. The source shows on every order. When a restaurant doesn't publish a part, such as a pump of syrup, the app uses USDA FoodData Central and marks it as an estimate.

**Does it use AI to guess nutrition?**
No. The numbers are the restaurants' own figures, added up. Estimates are marked.

**Who is it for?**
Anyone who eats out and has a calorie or protein goal: people losing weight, lifters, busy parents, travelers, shift workers, and people eating more protein.

**What does it cost?**
$29.99 per year with a 3-day free trial for new subscribers, or $9.99 per month.

**What data does it collect?**
None. There is no account and there are no ads. Location is optional and only sorts restaurants by distance on the phone. Apple Health is optional and read-only, used for body weight.

**Is it on Android?**
Not yet. CheatCode is iPhone only.

**Is CheatCode affiliated with the restaurants?**
No. Restaurant names and logos only identify the restaurants.
