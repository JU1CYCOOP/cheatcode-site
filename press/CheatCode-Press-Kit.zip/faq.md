# Greg Cooper, founder of CheatCode

Greg Cooper was about 220 pounds when he decided to get in shape. For a long time, that meant staying away from fast food completely and saying no a lot when friends wanted to grab a bite. He got down to 175, but he wanted a way to eat out without losing ground. So he went through restaurant nutrition charts, worked out orders that fit his calories and protein, and wrote down exactly how to ask for each one. He calls them cheat codes. CheatCode is those orders, plus hundreds more, in an app.

## Questions reporters ask

**Did you have to give up fast food to lose the weight?**
For a long time, yes. I stayed away from it because I didn't know what I could order, so I'd skip it even when my friends were going. That's what I wanted to fix. Now I know what to get, wherever we end up.

**What's a cheat code?**
A normal menu item ordered a specific way. No mayo, a sauce swapped for hot sauce, extra free veggies, a different size. Nothing secret and nothing the restaurant won't make.

**How is this different from MenuFit?**
MenuFit labels its numbers "estimated nutrition." CheatCode uses each restaurant's own published numbers and shows the source on every order. Its more than 1,600 cheat codes are written by hand and only sized to portions the restaurant actually sells. Every order shows a match percentage for your calories and protein, and every order can be made lighter, tastier, bigger or smaller, with a different side, another milk or more protein.

**How is this different from MyFitnessPal?**
Those apps ask you to log what you already ate. CheatCode tells you what to order before you order it, and gives you the words to say.

**Where do the numbers come from?**
Straight from each restaurant's published nutrition info, with the source on every order. If a chain doesn't publish something, the app uses the USDA number and marks it as an estimate. No AI guessing.

**Who is it for?**
People who eat out and care about calories or protein: people trying to lose weight, people who lift, parents, people who travel or work long shifts.

**Is it on Android?**
Not yet.

**Is it connected to the restaurants?**
No. CheatCode isn't affiliated with any of them.
