# Greg Cooper, founder of CheatCode

Greg Cooper weighed about 250 pounds and ate fast food most days. Diets that cut out restaurants never lasted, so he kept eating out and changed what he ordered instead. He went through restaurant nutrition charts, worked out orders that fit his calories and protein, and wrote down exactly how to ask for each one. He calls them cheat codes. He now weighs 175 pounds and lifts. CheatCode is those orders, plus hundreds more, in an app.

## Questions reporters ask

**Did you really lose the weight eating fast food?**
Yes. I ate out most days the whole time. What changed was what I ordered.

**What's a cheat code?**
A normal menu item ordered a specific way. No mayo, a sauce swapped for hot sauce, extra free veggies, a different size. Nothing secret and nothing the restaurant won't make.

**How is this different from MyFitnessPal?**
Those apps ask you to log what you already ate. CheatCode tells you what to order before you order it, and gives you the words to say.

**Where do the numbers come from?**
Straight from each restaurant's published nutrition info, with the source on every order. If a chain doesn't publish something, the app uses the USDA number and marks it as an estimate. No AI guessing.

**Who is it for?**
People who eat out and care about calories or protein: people trying to lose weight, people who lift, parents, people who travel or work long shifts.

**Is it on Android?**
Not yet.

**Is it connected to the restaurants?**
No. CheatCode isn't affiliated with any of them.
