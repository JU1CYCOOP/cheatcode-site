# CheatCode Fact Sheet

| | |
|---|---|
| **Product** | CheatCode: Restaurant Macros (iPhone app) |
| **Tagline** | Eat out. Hit your macros. |
| **Founder** | Greg Cooper |
| **Launched** | November 2026, App Store (worldwide) |
| **Platform** | iPhone (iOS) |
| **Category** | Food & Drink; Health & Fitness |
| **Price** | Subscription: $29.99/year with a 3-day free trial, or $9.99/month (USD) |
| **Download** | https://apps.apple.com/app/id6832425448 |
| **Website** | https://getcheatcode.app |
| **Contact** | press@getcheatcode.app |

## By the numbers
- 50+ national restaurant chains, fast food and sit-down
- 16,000+ menu items with the chain's own nutrition figures
- Nearly 500 cheat codes (custom orders built from the regular menu)
- 140+ cheat codes based on orders posted by creators on TikTok and Instagram
- 0 accounts, 0 ads, 0 personal data collected

## What it does
1. Sets a calorie and protein target per meal (from a short setup, or the user's own numbers).
2. Gives every order a match percentage for that person.
3. Offers cheat codes (custom orders) and plain menu items, best match first.
4. Sizes orders to the user's meal using only sizes the restaurant sells.
5. Lets users make an order lighter, tastier, bigger or smaller, add protein, swap a side or change the milk.
6. Builds a plate with a total and the exact words to order at the counter or drive-thru.
7. Includes build-your-own tools at chains such as Subway, Chipotle, Domino's, Starbucks and Dunkin'.
8. Labels orders: Budget friendly, Lean, High volume, Seasonal, Treat pick.
9. Supports keto, vegetarian, high-protein and low-fat diets.
10. Lists restaurants closest first.

## Data sources
- Each restaurant's own published nutrition information; the source and date show on every order.
- USDA FoodData Central for parts a restaurant does not publish, always marked "Estimate."

## Restaurants include
Applebee's, Arby's, Buffalo Wild Wings, Burger King, CAVA, Chick-fil-A, Chili's, Chipotle, Crisp & Green, Culver's, Dairy Queen, Domino's, Dunkin', Five Guys, IHOP, In-N-Out, Jersey Mike's, Jimmy John's, KFC, McDonald's, Olive Garden, Outback Steakhouse, Panda Express, Panera, Pizza Hut, Popeyes, Qdoba, Raising Cane's, Shake Shack, Sonic, Starbucks, Subway, Taco Bell, Texas Roadhouse, Wendy's, Whataburger, Wingstop, Zaxby's and more.

## Story angles
- **Eating out is the norm:** 58.9% of U.S. food spending went to food away from home in 2024 (USDA ERS), and about 1 in 3 adults eats fast food on a given day (CDC NCHS, 2021–2023).
- **Not another tracker:** CheatCode tells you what to order before you order, instead of logging what you ate afterwards.
- **Viral orders, real numbers:** the TikTok coffee and fast-food hacks, rebuilt from the chains' own nutrition data.
- **High protein on the road:** for gym-goers, travelers, shift workers and anyone eating more protein.
- **Privacy:** no account, no ads, nothing collected.

## Sources
- USDA Economic Research Service, Food Prices and Spending: https://www.ers.usda.gov/data-products/ag-and-food-statistics-charting-the-essentials/food-prices-and-spending
- CDC NCHS Data Brief No. 533, Fast-food Intake Among Adults in the United States, August 2021–August 2023: https://www.cdc.gov/nchs/products/databriefs/db533.htm

CheatCode is not affiliated with any restaurant listed. Restaurant names are trademarks of their respective owners.
