# CheatCode at a glance

| | |
|---|---|
| **What it is** | An iPhone app that tells you what to order at restaurants to fit your calorie and protein goal |
| **Founder** | Greg Cooper (went from about 220 to 175 pounds; built CheatCode so he could stop avoiding fast food) |
| **Launched** | November 2026, App Store |
| **Price** | $29.99/year after a 3-day free trial, or $9.99/month |
| **Download** | https://apps.apple.com/app/id6832425448 |
| **Press** | thecheatcodeteam@gmail.com · https://getcheatcode.app/press/ |

## The numbers
- 120+ restaurant chains
- 30,000+ menu items
- More than 1,000 cheat codes, about 250 of them based on orders people posted on TikTok and Instagram
- No account, no ads, nothing collected

## Two example cheat codes
**Subway: Roast Beef, No Mayo.** Order a roast beef on Artisan Italian, no mayo, with lettuce, tomatoes, cucumbers, green peppers, onions and yellow mustard. As a Footlong: 800 calories, 60 g protein.

**Raising Cane's: Five-Finger Double Decker.** Order the Chicken Sandwich by itself with no Cane's Sauce, plus 2 extra Chicken Fingers and a hot sauce packet. Stack the fingers on the sandwich. 920 calories, 69 g protein.

## What sets it apart
- Real numbers: the restaurant's own published nutrition, with the source on every order. Many apps in the category estimate with AI.
- Hand-built cheat codes, sized only to portions the restaurant sells.
- A match percentage on every order for your own calories and protein.
- Change any order with a tap: lighter, tastier, size, side, milk, more protein.
- Build your own at chains like Chipotle, Subway, Domino's and Starbucks.
- A step-by-step script to read at the counter.

## Where the numbers come from
The restaurant's own nutrition information, shown on every order. Anything a chain doesn't publish uses USDA FoodData Central and is labeled "Estimate."

## Some of the restaurants
Applebee's, Arby's, Buffalo Wild Wings, Burger King, CAVA, Chick-fil-A, Chili's, Chipotle, Dairy Queen, Domino's, Dunkin', Five Guys, IHOP, In-N-Out, Jersey Mike's, Jimmy John's, KFC, McDonald's, Olive Garden, Outback, Panda Express, Panera, Pizza Hut, Popeyes, Raising Cane's, Shake Shack, Sonic, Starbucks, Subway, Taco Bell, Texas Roadhouse, Wendy's, Whataburger, Wingstop and more.
